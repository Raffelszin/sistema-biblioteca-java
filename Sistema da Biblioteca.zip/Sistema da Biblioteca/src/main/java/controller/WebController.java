package com.seunome.biblioteca.controller;

import com.seunome.biblioteca.model.Livro;
import com.seunome.biblioteca.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class WebController {

    @Autowired
    private LivroRepository livroRepository;

    // Tela de Login
    @GetMapping("/")
    public String login() {
        return "login"; // Vai procurar um arquivo login.html no Thymeleaf
    }

    // Processar Login (MOCK simples conforme requisito)
    @PostMapping("/login")
    public String processarLogin(@RequestParam String username, @RequestParam String password) {
        if ("admin".equals(username) && "admin".equals(password)) {
            return "redirect:/dashboard";
        }
        return "redirect:/?error";
    }

    // Tela Principal com Listagem
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("livros", livroRepository.findAll());
        return "dashboard"; // Vai procurar o arquivo dashboard.html
    }

    // Adicionar Livro
    @PostMapping("/adicionar")
    public String adicionarLivro(@ModelAttribute Livro livro) {
        livro.setDisponivel(true);
        livroRepository.save(livro);
        return "redirect:/dashboard";
    }

    // Alterar Status (Emprestar/Devolver)
    @GetMapping("/status/{id}")
    public String alterarStatus(@PathVariable String id) {
        Livro livro = livroRepository.findById(id).orElse(null);
        if(livro != null) {
            livro.setDisponivel(!livro.isDisponivel());
            livroRepository.save(livro);
        }
        return "redirect:/dashboard";
    }

    // Excluir Livro
    @GetMapping("/excluir/{id}")
    public String excluirLivro(@PathVariable String id) {
        livroRepository.deleteById(id);
        return "redirect:/dashboard";
    }
}